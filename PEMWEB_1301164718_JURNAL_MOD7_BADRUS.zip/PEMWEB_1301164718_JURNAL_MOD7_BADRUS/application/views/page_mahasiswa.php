  <div class="container">
  	<div class="box">
      <h2>Data Mahasiswa</h2>
      <p>Tabel Data Mahasiswa Telkom Univerity</p>            
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>No</th>
            <th>nim</th>
            <th>Nama</th>
            <th>Kelas</th>
            <th>Jurusan</th>
            <th>Fakultas</th>
            <th class="text-center">Foto</th>
          </tr>
        </thead>
        <tbody>
          <!--
            ..:: QUESTION ::.. 
            Print a table from the results of Getmahasiswa_nim data, and display photos of each user with the 'assets / photo' path
          -->
          <!-- YOUR_CODE_HERE -->
          <?php echo base_url()?>index.php/web/mahasiswa"
        </tbody>
      </table>
    </div>
  </div>
</body>
</html>
