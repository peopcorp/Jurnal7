<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_web extends CI_Model {

	public function GetMahasiswa_nim(){
		/*
			..:: QUESTION ::.. 
			Function that can retrieve student data along with the name of the department [jurusan]. (clue: JOIN).
		*/
		// YOUR_CODE_HERE\
		
		// $data = $this->db->query("SELECT mahasiswa JOIN jurusan WHERE mahasiswa.id_jurusan = jurusan.id_jurusan");
		// return $data;
		
		return $this->db->get('mahasiswa');
	}
	public function Getjurusan_nim(){
		/*
			..:: QUESTION ::.. 
			Function that can retrieve department [jurusan] data and the number of students in each department [jurusan]. (clue: Join, Aggregate Function)
		*/
		// YOUR_CODE_HERE
		return $this->db->get('jurusan');

	}
}

