<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web extends CI_Controller {

	public function __construct()
 	{
		parent::__construct();
		/*
			..:: QUESTION ::.. 
			Doing Load Model M_web
		*/
		// YOUR_CODE_HERE
		$this->load->model('M_web');
 		$this->load->helper('url');
	}
		
	/*
		..:: QUESTION ::.. 
		Define the assosiative array $data
		[YOUR_STUDENT_ID (int), YOUR_NAME (str), YOUR_CAMPUS (str)]
	*/
	// YOUR_CODE_HERE
	public $data = array(
		"nim" => 1301164718,
		"nama" => 'Ryan Ramdhani',
		"kampus"=> ''
	);

	public function index()
	{
		$this->load->view('page_header');
		$this->load->view('page_index');

	}

	public function mahasiswa()
	{
		$data['mahasiwa'] = $this->M_web->GetMahasiswa_nim()->result();
		$this->load->view('page_header');
		$this->load->view('page_mahasiswa.php',$data);

	}

	public function jurusan()
	{
		$data['jurusan'] = $this->M_web->Getjurusan_nim()->result();
		$this->load->view('page_header');
		$this->load->view('page_jurusan.php',$data);

	}
}
